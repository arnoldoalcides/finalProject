#ifndef LINUX_SPI_MAX7301_H
#define LINUX_SPI_MAX7301_H

struct max7301_platform_data {
	/* number assigned to the first GPIO */
	unsigned	base;
};

#endif
